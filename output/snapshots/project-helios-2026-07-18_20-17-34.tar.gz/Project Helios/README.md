# Project Helios

A lightweight Debian-based HTPC appliance.

## Version 1

Base system:
- Debian 13 minimal
- Xorg
- Openbox
- Flex Launcher

Applications:
- Moonlight
- Plex HTPC
- FreeTube
- Brave Browser
- Spotify
- MPV
- PCManFM
- SMB support

Version 1 focuses on stability, testing and simple operation.

Future versions may add:
- Custom theme and branding
- Custom background
- Improved remote control support
- App selection during installation
- Reusable installer or ISO
