#!/usr/bin/env bash

set -Eeuo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$PROJECT_DIR/output/logs"
LOG_FILE="$LOG_DIR/install.log"

mkdir -p "$LOG_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "=========================================="
echo " Project Helios: Master Installer"
echo "=========================================="
echo

if [[ $EUID -ne 0 ]]; then
    echo "ERROR: Run this installer with sudo:"
    echo "sudo \"$PROJECT_DIR/install.sh\""
    exit 1
fi

run_step() {
    local STEP_NAME="$1"
    local SCRIPT_PATH="$2"

    echo
    echo "------------------------------------------"
    echo "$STEP_NAME"
    echo "------------------------------------------"

    if [[ ! -x "$SCRIPT_PATH" ]]; then
        echo "ERROR: Script is missing or not executable:"
        echo "$SCRIPT_PATH"
        exit 1
    fi

    "$SCRIPT_PATH"

    echo
    echo "Completed: $STEP_NAME"
}

run_step \
    "Step 1 of 4: Install base Debian packages" \
    "$PROJECT_DIR/scripts/install-base.sh"

run_step \
    "Step 2 of 4: Install external applications" \
    "$PROJECT_DIR/scripts/install-external.sh"

run_step \
    "Step 3 of 4: Configure the Helios system" \
    "$PROJECT_DIR/scripts/configure-system.sh"

run_step \
    "Step 4 of 4: Configure Flex Launcher" \
    "$PROJECT_DIR/scripts/configure-flex.sh"

echo
echo "=========================================="
echo " Core Project Helios installation complete"
echo "=========================================="
echo
echo "Flatpak applications must now be installed"
echo "from the normal Helios user account."
echo
echo "Log in as the Helios user and run:"
echo
echo "  \"$PROJECT_DIR/scripts/install-apps.sh\""
echo
echo "Afterwards, verify video acceleration with:"
echo
echo "  \"$PROJECT_DIR/scripts/verify-vaapi.sh\""
echo
echo "Master log saved to:"
echo "$LOG_FILE"
